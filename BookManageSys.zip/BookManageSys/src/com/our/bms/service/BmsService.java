package com.our.bms.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.our.bms.dao.BmsDao;
import com.our.bms.vo.BmsVo;

public class BmsService {
	
	
	BmsDao bmsDao = new BmsDao();
	
	
	public void addBook(HttpServletRequest request, HttpServletResponse response) {
		
		
		String b_name = request.getParameter("b_name");
		String b_writer = request.getParameter("b_writer");
		String b_publisher = request.getParameter("b_publisher");
		int b_publish_year = Integer.parseInt(request.getParameter("b_publish_year"));
		String b_isbn = request.getParameter("b_isbn");
		String b_data_type = request.getParameter("b_data_type");
		String b_call_number = request.getParameter("b_call_number");
		String b_library = request.getParameter("b_library");
		String b_library_room = request.getParameter("b_library_room");
		String b_data_status = request.getParameter("b_data_status");
		
		int result = bmsDao.insertBook(new BmsVo(b_name, b_writer, b_publisher, b_publish_year, b_isbn, b_data_type, b_call_number, b_library, b_library_room, b_data_status));
		
		if (result > 0) 
			System.out.println("INSERT SUCCESS");
		else 
			System.out.println("INSERT FAIL");
	}
	
	public void getBooks (HttpServletRequest request, HttpServletResponse response) {
		
		ArrayList<BmsVo> bmsVos = bmsDao.selectBooks();
		request.setAttribute("bmsVos", bmsVos);
		
	
	}
	

	public void getBook(HttpServletRequest request, HttpServletResponse response) {
		
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		
		BmsVo bmsVo = bmsDao.selectBook(b_id);
		
		if (bmsVo != null) {
			System.out.println("GETBOOK SUCCESS");
			request.setAttribute("bmsVo", bmsVo);
		} else {
			System.out.println("GETBOOK FAIL");
		}
	}

	

	public void removeBook(HttpServletRequest request, HttpServletResponse response) {
		
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		
		int result = bmsDao.deleteBook(b_id);
		
		if (result > 0) {
			System.out.println("DELETE SUCCESS");
		} else { 
			System.out.println("DELETE FAIL");
			
		}
		
		
	}

	public void modifyConfirm(HttpServletRequest request, HttpServletResponse response) {
		
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		String b_name = request.getParameter("b_name");
		String b_writer = request.getParameter("b_writer");
		String b_publisher = request.getParameter("b_publisher");
		int b_publish_year = Integer.parseInt(request.getParameter("b_publish_year"));
		String b_isbn = request.getParameter("b_isbn");
		String b_data_type = request.getParameter("b_data_type");
		String b_call_number = request.getParameter("b_call_number");
		String b_library = request.getParameter("b_library");
		String b_library_room = request.getParameter("b_library_room");
		String b_data_status = request.getParameter("b_data_status");
		
		BmsVo bmsVo = new BmsVo(b_id, b_name, b_writer, b_publisher, 
				b_publish_year, b_isbn, b_data_type, b_call_number, 
				b_library, b_library_room, b_data_status);
		
		int result = bmsDao.update(bmsVo);
		
		if (result > 0) {
			System.out.println("UPDATE SUCCESS");
			request.setAttribute("bmsVo", bmsVo);
		} else { 
			System.out.println("UPDATE FAIL");
			
		}
		
		
	}
}
