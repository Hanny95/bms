package com.our.bms.vo;

public class BmsVo {

	private int b_id;
	private String b_name;
	private String b_writer;
	private String b_publisher;
	private int b_publish_year;
	private String b_isbn;
	private String b_data_type;
	private String b_call_number;
	private String b_library;
	private String b_library_room;
	private String b_data_status;
	
	public BmsVo() {
		
		
	}
	
	public BmsVo(int b_id, String b_name, String b_writer, String b_publisher, int b_publish_year, String b_isbn, String b_data_type, 
			String b_call_number, String b_library, String b_library_room, String b_data_status) {
		
		this.b_id = b_id;
		this.b_name = b_name;
		this.b_writer = b_writer;
		this.b_publisher = b_publisher;
		this.b_publish_year = b_publish_year;
		this.b_isbn = b_isbn;
		this.b_data_type = b_data_type;
		this.b_call_number = b_call_number;
		this.b_library = b_library;
		this.b_library_room = b_library_room;
		this.b_data_status = b_data_status;
		
		
	}
	
	public BmsVo(String b_name, String b_writer, String b_publisher, int b_publish_year, String b_isbn, String b_data_type, 
			String b_call_number, String b_library, String b_library_room, String b_data_status) {
		

		this.b_name = b_name;
		this.b_writer = b_writer;
		this.b_publisher = b_publisher;
		this.b_publish_year = b_publish_year;
		this.b_isbn = b_isbn;
		this.b_data_type = b_data_type;
		this.b_call_number = b_call_number;
		this.b_library = b_library;
		this.b_library_room = b_library_room;
		this.b_data_status = b_data_status;
		
		
	}
	
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_writer() {
		return b_writer;
	}
	public void setB_writer(String b_writer) {
		this.b_writer = b_writer;
	}
	public String getB_publisher() {
		return b_publisher;
	}
	public void setB_publisher(String b_publisher) {
		this.b_publisher = b_publisher;
	}
	public int getB_publish_year() {
		return b_publish_year;
	}
	public void setB_publish_year(int b_publish_year) {
		this.b_publish_year = b_publish_year;
	}
	public String getB_isbn() {
		return b_isbn;
	}
	public void setB_isbn(String b_isbn) {
		this.b_isbn = b_isbn;
	}
	public String getB_data_type() {
		return b_data_type;
	}
	public void setB_data_type(String b_data_type) {
		this.b_data_type = b_data_type;
	}
	public String getB_call_number() {
		return b_call_number;
	}
	public void setB_call_number(String b_call_number) {
		this.b_call_number = b_call_number;
	}
	public String getB_library() {
		return b_library;
	}
	public void setB_library(String b_library) {
		this.b_library = b_library;
	}
	public String getB_library_room() {
		return b_library_room;
	}
	public void setB_library_room(String b_library_room) {
		this.b_library_room = b_library_room;
	}
	public String getB_data_status() {
		return b_data_status;
	}
	public void setB_data_status(String b_data_status) {
		this.b_data_status = b_data_status;
	}
	
	
	
}
