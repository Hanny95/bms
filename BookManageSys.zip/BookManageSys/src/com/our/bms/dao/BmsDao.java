package com.our.bms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.our.bms.vo.BmsVo;


public class BmsDao {
	
	
	DataSource dataSource;
	
	public BmsDao() {
		
		try {
			
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/mariadb");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public int insertBook(BmsVo bmsVo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {

			conn = dataSource.getConnection();
			
			String sql = "INSERT INTO tbl_book(b_name, b_writer, b_publisher, b_publish_year, b_isbn, b_data_type, b_call_number, b_library, b_library_room, b_data_status) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bmsVo.getB_name());
			pstmt.setString(2, bmsVo.getB_writer());
			pstmt.setString(3, bmsVo.getB_publisher());
			pstmt.setInt(4, bmsVo.getB_publish_year());
			pstmt.setString(5, bmsVo.getB_isbn());
			pstmt.setString(6, bmsVo.getB_data_type());
			pstmt.setString(7, bmsVo.getB_call_number());
			pstmt.setString(8, bmsVo.getB_library());
			pstmt.setString(9, bmsVo.getB_library_room());
			pstmt.setString(10, bmsVo.getB_data_status());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
		
	}
	


	public ArrayList<BmsVo> selectBooks() {
		
		Connection conn = null;
		PreparedStatement pstmt = null;   				
		ResultSet rs = null;     
		
		ArrayList<BmsVo> bmsVos = new ArrayList<BmsVo>();
		
		try {
			
			conn = dataSource.getConnection();
			
			String sql = "SELECT * FROM tbl_book";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
		
			
			while (rs.next()) {
				
				
				
				int b_id = rs.getInt("b_id");
				String b_name = rs.getString("b_name");
				String b_writer = rs.getString("b_writer");
				String b_publisher = rs.getString("b_publisher");
				int b_publish_year = rs.getInt("b_publish_year");
				String b_isbn = rs.getString("b_isbn");
				String b_data_type = rs.getString("b_data_type");
				String b_call_number = rs.getString("b_call_number");
				String b_library = rs.getString("b_library");
				String b_library_room = rs.getString("b_library_room");
				String b_data_status = rs.getString("b_data_status");
				
								
				
				BmsVo bmsVo = new BmsVo(b_id, b_name, b_writer, b_publisher, b_publish_year, b_isbn, 
						b_data_type, b_call_number, b_library, b_library_room, b_data_status);
				
				bmsVos.add(bmsVo);
				
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				
			} finally {
				try {
					
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
					if (conn != null) conn.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			
			// ArrayList 반환
			return bmsVos;
	}

	
	
	public BmsVo selectBook(int bId) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;   				
		ResultSet rs = null;     
		
		ArrayList<BmsVo> bmsVos = new ArrayList<BmsVo>();
		
		try {
			
			conn = dataSource.getConnection();
			
			String sql = "SELECT * FROM tbl_book WHERE b_id =" + bId;
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
		
			
			while (rs.next()) {
				
				
				
				int b_id = rs.getInt("b_id");
				String b_name = rs.getString("b_name");
				String b_writer = rs.getString("b_writer");
				String b_publisher = rs.getString("b_publisher");
				int b_publish_year = rs.getInt("b_publish_year");
				String b_isbn = rs.getString("b_isbn");
				String b_data_type = rs.getString("b_data_type");
				String b_call_number = rs.getString("b_call_number");
				String b_library = rs.getString("b_library");
				String b_library_room = rs.getString("b_library_room");
				String b_data_status = rs.getString("b_data_status");
				
								
				
				BmsVo bmsVo = new BmsVo(b_id, b_name, b_writer, b_publisher, b_publish_year, b_isbn, 
						b_data_type, b_call_number, b_library, b_library_room, b_data_status);
				
				bmsVos.add(bmsVo);
				
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				
			} finally {
				try {
					
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
					if (conn != null) conn.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			
			
			return bmsVos.get(0) != null? bmsVos.get(0): null;
	}

	
	
	public int deleteBook(int b_id) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {

			conn = dataSource.getConnection();

			String sql = "DELETE FROM tbl_book WHERE b_id = ? ";
					
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, b_id);
	
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
		
	}



	public int update(BmsVo bmsVo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {

			conn = dataSource.getConnection();

			String sql = "UPDATE tbl_book SET "
					+ "b_name = ? ,"
					+ "b_writer = ?, "
					+ "b_publisher = ?, "
					+ "b_publish_year = ?, "
					+ "b_isbn = ?, "
					+ "b_data_type = ?, "
					+ "b_call_number = ?, "
					+ "b_library = ?, "
					+ "b_library_room = ?, "
					+ "b_data_status = ? "
					+ "WHERE b_id = ? ";
					
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bmsVo.getB_name());
			pstmt.setString(2, bmsVo.getB_writer());
			pstmt.setString(3, bmsVo.getB_publisher());
			pstmt.setInt(4, bmsVo.getB_publish_year());
			pstmt.setString(5, bmsVo.getB_isbn());
			pstmt.setString(6, bmsVo.getB_data_type());
			pstmt.setString(7, bmsVo.getB_call_number());
			pstmt.setString(8, bmsVo.getB_library());
			pstmt.setString(9, bmsVo.getB_library_room());
			pstmt.setString(10, bmsVo.getB_data_status());
			pstmt.setInt(11, bmsVo.getB_id());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
		
	}

	

}
