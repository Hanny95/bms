package com.our.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.our.bms.service.BmsService;

/**
 * Servlet implementation class BmsController
 */
@WebServlet("*.bms")
public class BmsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BmsController() {
        super();
      
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		
		
		BmsService bmsService = null;
		String nextPage = null;
		
		
		if(command.equals("/register.bms")) {
			
			nextPage = "register.jsp";
			
		} else if (command.equals("/registerConfirm.bms")) {
			
			bmsService = new BmsService();
			bmsService.addBook(request, response);
			nextPage = "/list.bms";
			
		} else if (command.equals("/list.bms")) {
			
			bmsService = new BmsService();
			bmsService.getBooks(request, response);
			nextPage = "list.jsp";
			
		} else if(command.equals("/detail.bms")) {
			
			bmsService = new BmsService();
			bmsService.getBook(request, response);
			nextPage = "detail.jsp";
			
			
		} else if (command.equals("/modify.bms")) {
			
			bmsService = new BmsService();
			bmsService.getBook(request, response);
			nextPage = "modifyForm.jsp";
			
		} else if (command.equals("/modifyConfirm.bms")) {
			
			
			bmsService = new BmsService();
			bmsService.modifyConfirm(request, response);
			nextPage = "detail.jsp";
			
			
			
		} else if (command.equals("/delete.bms")) {
			
			bmsService = new BmsService();
			bmsService.removeBook(request, response);
			nextPage = "/list.bms";
			
		}
		
		
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(nextPage);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
