function removeBook(uri) {
	
	var returnData = confirm("정말 삭제하시겠습니까?");
	
	if (returnData) {
		location.href = uri;
	} else {
		
	}
		
		
}