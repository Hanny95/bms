function addFun() {
	
	var register_form = document.registerForm;
	
	if(register_form.b_name.value=="") {
		alert('도서 이름을 입력하세요');
		register_form.b_name.focus();
	} else if(register_form.b_writer.value=="") {
		alert('저자를 입력하세요');
		register_form.b_writer.focus();
	} else if(register_form.b_publisher.value=="") {
		alert('발행처를 입력하세요');
		register_form.b_publisher.focus();
	} else if(register_form.b_publish_year.value=="") {
		alert('발행년도를 입력하세요');
		register_form.b_publish_year.focus();
	} else if(register_form.b_isbn.value=="") {
		alert('ISBN을 입력하세요');
		register_form.b_isbn.focus();
	} else if(register_form.b_data_type.value=="") {
		alert('자료형태를 입력하세요');
		register_form.b_data_type.focus();
	} else if(register_form.b_call_number.value=="") {
		alert('청구기호를 입력하세요');
		register_form.b_call_number.focus();
	} else if(register_form.b_library.value=="") {
		alert('도서관을 입력하세요');
		register_form.b_library.focus();
	} else if(register_form.b_library_room.value=="") {
		alert('자료실을 입력하세요');
		register_form.b_library_room.focus();
	} else if(register_form.b_data_status.value=="") {
		alert('자료상태를 입력하세요');
		register_form.b_data_status.focus();
	} else {
		register_form.submit();
	}
	
}