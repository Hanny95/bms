function addFun() {
	
	var register_form = document.registerForm;
	
	
	if(register_form.s_name.value=="") {
		alert('이름을 입력하세요');
		register_form.s_name.focus();
		
	} else if(register_form.s_gender.value=="") {
		alert('성별을 선택하세요');
		register_form.s_gender.focus();
		
	} else if(register_form.s_grade.value=="") {
		alert('학년을 선택하세요');
		register_form.s_grade.focus();
		
	} else if(register_form.s_number.value=="") {
		alert('번호를 입력하세요');
		register_form.s_number.focus();
		
	} else if(register_form.s_major.value=="") {
		alert('전공을 선택하세요');
		register_form.s_major.focus();
		
	} else if(register_form.s_phone.value=="") {
		alert('연락처를 입력하세요');
		register_form.s_phone.focus();
		
	} else if(register_form.s_mail.value=="") {
		alert('메일을 입력하세요');
		register_form.s_mail.focus();
	

	} else if(register_form.s_absence.value=="") {
		alert('휴학을 선택하세요');
		register_form.s_absence.focus();
		
	}  else {
		register_form.submit();
		
		
	};
	
}